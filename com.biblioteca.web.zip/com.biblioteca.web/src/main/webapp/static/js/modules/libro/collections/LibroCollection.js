"use strict";

var LibroCollection = Backbone.Collection.extend({
	model : LibroModel
});